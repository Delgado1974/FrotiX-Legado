namespace FrotiX.Repository.IRepository
{
    public partial interface IUnitOfWork
    {
        IRepactuacaoVeiculoRepository RepactuacaoVeiculo { get; }
    }
}
