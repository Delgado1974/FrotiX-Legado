-- ============================================================================
-- FROTIX - 06: ÍNDICES DE OTIMIZAÇÃO
-- ============================================================================
-- Este script cria índices para otimizar as consultas do Dashboard
-- e das Stored Procedures de normalização e estatísticas
--
-- EXECUÇÃO: Após todos os outros scripts (opcional mas recomendado)
-- ============================================================================

USE FrotiX
GO

PRINT ''
PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  FROTIX - SCRIPT 06: ÍNDICES DE OTIMIZAÇÃO                           ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''
PRINT 'Início: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT ''

-- ============================================================================
-- ÍNDICES NA TABELA VIAGEM
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  TABELA: Viagem'
PRINT '────────────────────────────────────────────────────────────────────────'

-- Remover e recriar para garantir estrutura atualizada

-- IX_Viagem_DataInicial_Status
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Viagem_DataInicial_Status' AND object_id = OBJECT_ID('Viagem'))
BEGIN
    DROP INDEX IX_Viagem_DataInicial_Status ON Viagem
    PRINT '  [DROP] IX_Viagem_DataInicial_Status'
END

CREATE NONCLUSTERED INDEX IX_Viagem_DataInicial_Status 
    ON Viagem(DataInicial, Status)
    INCLUDE (VeiculoId, MotoristaId, KmInicial, KmFinal, Minutos,
             CustoVeiculo, CustoMotorista, CustoOperador, CustoLavador, CustoCombustivel)
PRINT '  [CREATE] IX_Viagem_DataInicial_Status'

-- IX_Viagem_DataInicialNormalizada
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Viagem_DataInicialNormalizada' AND object_id = OBJECT_ID('Viagem'))
BEGIN
    DROP INDEX IX_Viagem_DataInicialNormalizada ON Viagem
    PRINT '  [DROP] IX_Viagem_DataInicialNormalizada'
END

CREATE NONCLUSTERED INDEX IX_Viagem_DataInicialNormalizada 
    ON Viagem(DataInicialNormalizada, Status)
    INCLUDE (VeiculoId, MotoristaId, KmInicialNormalizado, KmFinalNormalizado, MinutosNormalizado,
             CustoVeiculo, CustoMotorista, CustoOperador, CustoLavador, CustoCombustivel)
    WHERE DataInicialNormalizada IS NOT NULL
PRINT '  [CREATE] IX_Viagem_DataInicialNormalizada (filtrado)'

-- IX_Viagem_VeiculoId_Status
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Viagem_VeiculoId_Status' AND object_id = OBJECT_ID('Viagem'))
BEGIN
    DROP INDEX IX_Viagem_VeiculoId_Status ON Viagem
    PRINT '  [DROP] IX_Viagem_VeiculoId_Status'
END

CREATE NONCLUSTERED INDEX IX_Viagem_VeiculoId_Status 
    ON Viagem(VeiculoId, Status)
    INCLUDE (DataInicial, Minutos, KmInicial, KmFinal)
    WHERE VeiculoId IS NOT NULL
PRINT '  [CREATE] IX_Viagem_VeiculoId_Status (filtrado)'

-- IX_Viagem_FoiNormalizada
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Viagem_FoiNormalizada' AND object_id = OBJECT_ID('Viagem'))
BEGIN
    DROP INDEX IX_Viagem_FoiNormalizada ON Viagem
    PRINT '  [DROP] IX_Viagem_FoiNormalizada'
END

CREATE NONCLUSTERED INDEX IX_Viagem_FoiNormalizada 
    ON Viagem(FoiNormalizada, DataNormalizacao)
    INCLUDE (DataInicial, TipoNormalizacao)
    WHERE FoiNormalizada = 1
PRINT '  [CREATE] IX_Viagem_FoiNormalizada (filtrado)'

PRINT ''

-- ============================================================================
-- ÍNDICES NA TABELA ABASTECIMENTO
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  TABELA: Abastecimento'
PRINT '────────────────────────────────────────────────────────────────────────'

-- IX_Abastecimento_VeiculoId_DataHora
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Abastecimento_VeiculoId_DataHora' AND object_id = OBJECT_ID('Abastecimento'))
BEGIN
    DROP INDEX IX_Abastecimento_VeiculoId_DataHora ON Abastecimento
    PRINT '  [DROP] IX_Abastecimento_VeiculoId_DataHora'
END

CREATE NONCLUSTERED INDEX IX_Abastecimento_VeiculoId_DataHora 
    ON Abastecimento(VeiculoId, DataHora)
    INCLUDE (Hodometro, KmRodado, Litros)
PRINT '  [CREATE] IX_Abastecimento_VeiculoId_DataHora'

PRINT ''

-- ============================================================================
-- ATUALIZAR ESTATÍSTICAS
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ATUALIZANDO ESTATÍSTICAS'
PRINT '────────────────────────────────────────────────────────────────────────'

UPDATE STATISTICS Viagem
PRINT '  [UPDATE] Estatísticas da tabela Viagem'

UPDATE STATISTICS ViagemEstatistica
PRINT '  [UPDATE] Estatísticas da tabela ViagemEstatistica'

UPDATE STATISTICS Abastecimento
PRINT '  [UPDATE] Estatísticas da tabela Abastecimento'

UPDATE STATISTICS VeiculoPadraoViagem
PRINT '  [UPDATE] Estatísticas da tabela VeiculoPadraoViagem'

PRINT ''

-- ============================================================================
-- RESUMO FINAL
-- ============================================================================

PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  SCRIPT 06 CONCLUÍDO COM SUCESSO!                                    ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''
PRINT '  ÍNDICES CRIADOS:'
PRINT '  ────────────────────────────────────────────'
PRINT '    Viagem:'
PRINT '      ✓ IX_Viagem_DataInicial_Status'
PRINT '      ✓ IX_Viagem_DataInicialNormalizada (filtrado)'
PRINT '      ✓ IX_Viagem_VeiculoId_Status (filtrado)'
PRINT '      ✓ IX_Viagem_FoiNormalizada (filtrado)'
PRINT ''
PRINT '    Abastecimento:'
PRINT '      ✓ IX_Abastecimento_VeiculoId_DataHora'
PRINT ''
PRINT '    ViagemEstatistica:'
PRINT '      ✓ IX_ViagemEstatistica_DataReferencia (script 01)'
PRINT '      ✓ IX_ViagemEstatistica_DataRef_Custos (script 01)'
PRINT '      ✓ IX_ViagemEstatistica_DataRef_Viagens (script 01)'
PRINT ''
PRINT '    VeiculoPadraoViagem:'
PRINT '      ✓ IX_VeiculoPadraoViagem_VeiculoId (script 02)'
PRINT '      ✓ IX_VeiculoPadraoViagem_TipoUso (script 02)'
PRINT ''
PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  INSTALAÇÃO COMPLETA!                                                ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''
PRINT '  RESUMO DA INSTALAÇÃO:'
PRINT '  ────────────────────────────────────────────'
PRINT '    01 - Tabela ViagemEstatistica'
PRINT '    02 - Campos normalizados + SPs de normalização'
PRINT '    03 - SP de estatísticas (usa campos normalizados)'
PRINT '    04 - Carga inicial (histórico completo)'
PRINT '    05 - Job automático (a cada 30 minutos)'
PRINT '    06 - Índices de otimização'
PRINT ''
PRINT '  O SISTEMA ESTÁ PRONTO PARA USO!'
PRINT ''
PRINT 'Fim: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT ''
GO
