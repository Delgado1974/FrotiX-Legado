-- ============================================================================
-- FROTIX - 03: STORED PROCEDURE DE ESTATÍSTICAS
-- ============================================================================
-- Esta SP calcula e popula/atualiza os dados da tabela ViagemEstatistica
-- usando os campos normalizados (com fallback para originais)
--
-- EXECUÇÃO: Após o script 02
-- ============================================================================

USE FrotiX
GO

PRINT ''
PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  FROTIX - SCRIPT 03: SP DE ESTATÍSTICAS                              ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''
PRINT 'Início: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT ''

-- ============================================================================
-- DROP SP SE EXISTIR
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 1: Removendo SP existente'
PRINT '────────────────────────────────────────────────────────────────────────'

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'sp_AtualizarViagemEstatistica')
BEGIN
    DROP PROCEDURE sp_AtualizarViagemEstatistica
    PRINT '  [DROP] Procedure sp_AtualizarViagemEstatistica removida'
END
ELSE
BEGIN
    PRINT '  [INFO] Procedure sp_AtualizarViagemEstatistica não existia'
END

PRINT ''
GO

-- ============================================================================
-- CRIAR SP
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 2: Criando SP sp_AtualizarViagemEstatistica'
PRINT '────────────────────────────────────────────────────────────────────────'
GO

CREATE PROCEDURE sp_AtualizarViagemEstatistica
    @DataInicio DATE = NULL,
    @DataFim DATE = NULL,
    @ApenasHoje BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRY
        -- ===================================================================
        -- DEFINIR PERÍODO
        -- ===================================================================
        
        IF @ApenasHoje = 1
        BEGIN
            SET @DataInicio = CAST(GETDATE() AS DATE)
            SET @DataFim = CAST(GETDATE() AS DATE)
        END
        
        IF @DataInicio IS NULL
            SET @DataInicio = CAST(DATEADD(DAY, -30, GETDATE()) AS DATE)
        
        IF @DataFim IS NULL
            SET @DataFim = CAST(GETDATE() AS DATE)
        
        PRINT '  [EXEC] Período: ' + CONVERT(VARCHAR(10), @DataInicio, 103) + ' até ' + CONVERT(VARCHAR(10), @DataFim, 103)
        
        -- ===================================================================
        -- CONSTANTES
        -- ===================================================================
        DECLARE @KM_MAXIMO_POR_VIAGEM DECIMAL(18,2) = 2000
        
        -- ===================================================================
        -- TABELA TEMPORÁRIA COM TODAS AS DATAS
        -- ===================================================================
        
        CREATE TABLE #Datas (DataReferencia DATE PRIMARY KEY)
        
        ;WITH CTE_Datas AS (
            SELECT @DataInicio AS DataReferencia
            UNION ALL
            SELECT DATEADD(DAY, 1, DataReferencia)
            FROM CTE_Datas
            WHERE DataReferencia < @DataFim
        )
        INSERT INTO #Datas (DataReferencia)
        SELECT DataReferencia FROM CTE_Datas
        OPTION (MAXRECURSION 10000)
        
        DECLARE @TotalDias INT = (SELECT COUNT(*) FROM #Datas)
        PRINT '         Dias a processar: ' + CAST(@TotalDias AS VARCHAR)
        
        -- ===================================================================
        -- PROCESSAR CADA DIA
        -- ===================================================================
        
        DECLARE @DataAtual DATE
        DECLARE @Contador INT = 0
        
        -- Variáveis
        DECLARE @TotalViagens INT, @ViagensFinalizadas INT, @ViagensEmAndamento INT
        DECLARE @ViagensAgendadas INT, @ViagensCanceladas INT
        DECLARE @CustoTotal DECIMAL(18,2), @CustoVeiculo DECIMAL(18,2), @CustoMotorista DECIMAL(18,2)
        DECLARE @CustoOperador DECIMAL(18,2), @CustoLavador DECIMAL(18,2), @CustoCombustivel DECIMAL(18,2)
        DECLARE @QuilometragemTotal DECIMAL(18,2), @QuilometragemMedia DECIMAL(18,2), @ViagensComKm INT
        
        -- JSONs
        DECLARE @ViagensPorStatusJson NVARCHAR(MAX), @ViagensPorMotoristaJson NVARCHAR(MAX)
        DECLARE @ViagensPorVeiculoJson NVARCHAR(MAX), @ViagensPorFinalidadeJson NVARCHAR(MAX)
        DECLARE @ViagensPorRequisitanteJson NVARCHAR(MAX), @ViagensPorSetorJson NVARCHAR(MAX)
        DECLARE @CustosPorMotoristaJson NVARCHAR(MAX), @CustosPorVeiculoJson NVARCHAR(MAX)
        DECLARE @KmPorVeiculoJson NVARCHAR(MAX), @CustosPorTipoJson NVARCHAR(MAX)
        
        DECLARE cur_Datas CURSOR LOCAL FAST_FORWARD FOR
            SELECT DataReferencia FROM #Datas ORDER BY DataReferencia
        
        OPEN cur_Datas
        FETCH NEXT FROM cur_Datas INTO @DataAtual
        
        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @Contador = @Contador + 1
            
            -- Resetar variáveis
            SELECT @TotalViagens = 0, @ViagensFinalizadas = 0, @ViagensEmAndamento = 0
            SELECT @ViagensAgendadas = 0, @ViagensCanceladas = 0
            SELECT @CustoTotal = 0, @CustoVeiculo = 0, @CustoMotorista = 0
            SELECT @CustoOperador = 0, @CustoLavador = 0, @CustoCombustivel = 0
            SELECT @QuilometragemTotal = 0, @QuilometragemMedia = 0, @ViagensComKm = 0
            SELECT @ViagensPorStatusJson = NULL, @ViagensPorMotoristaJson = NULL
            SELECT @ViagensPorVeiculoJson = NULL, @ViagensPorFinalidadeJson = NULL
            SELECT @ViagensPorRequisitanteJson = NULL, @ViagensPorSetorJson = NULL
            SELECT @CustosPorMotoristaJson = NULL, @CustosPorVeiculoJson = NULL
            SELECT @KmPorVeiculoJson = NULL, @CustosPorTipoJson = NULL
            
            -- =============================================================
            -- ESTATÍSTICAS BÁSICAS (usa COALESCE para campos normalizados)
            -- =============================================================
            
            SELECT 
                @TotalViagens = ISNULL(COUNT(*), 0),
                @ViagensFinalizadas = ISNULL(SUM(CASE WHEN Status = 'Realizada' THEN 1 ELSE 0 END), 0),
                @ViagensEmAndamento = ISNULL(SUM(CASE WHEN Status = 'Aberta' THEN 1 ELSE 0 END), 0),
                @ViagensAgendadas = ISNULL(SUM(CASE WHEN Status = 'Agendada' THEN 1 ELSE 0 END), 0),
                @ViagensCanceladas = ISNULL(SUM(CASE WHEN Status = 'Cancelada' THEN 1 ELSE 0 END), 0)
            FROM Viagem
            WHERE CAST(COALESCE(DataInicialNormalizada, DataInicial) AS DATE) = @DataAtual
            
            -- =============================================================
            -- CUSTOS (APENAS VIAGENS REALIZADAS)
            -- =============================================================
            
            SELECT 
                @CustoVeiculo = ISNULL(SUM(ISNULL(CustoVeiculo, 0)), 0),
                @CustoMotorista = ISNULL(SUM(ISNULL(CustoMotorista, 0)), 0),
                @CustoOperador = ISNULL(SUM(ISNULL(CustoOperador, 0)), 0),
                @CustoLavador = ISNULL(SUM(ISNULL(CustoLavador, 0)), 0)
            FROM Viagem
            WHERE CAST(COALESCE(DataInicialNormalizada, DataInicial) AS DATE) = @DataAtual
              AND Status = 'Realizada'
            
            -- Custo Combustível e KM
            SELECT 
                @CustoCombustivel = ISNULL(SUM(ISNULL(CustoCombustivel, 0)), 0),
                @QuilometragemTotal = ISNULL(SUM(
                    COALESCE(KmFinalNormalizado, KmFinal, 0) - COALESCE(KmInicialNormalizado, KmInicial, 0)
                ), 0)
            FROM Viagem
            WHERE CAST(COALESCE(DataInicialNormalizada, DataInicial) AS DATE) = @DataAtual
              AND Status = 'Realizada'
              AND COALESCE(KmInicialNormalizado, KmInicial) IS NOT NULL 
              AND COALESCE(KmFinalNormalizado, KmFinal) IS NOT NULL
              AND COALESCE(KmFinalNormalizado, KmFinal) >= COALESCE(KmInicialNormalizado, KmInicial)
              AND (COALESCE(KmFinalNormalizado, KmFinal) - COALESCE(KmInicialNormalizado, KmInicial)) <= @KM_MAXIMO_POR_VIAGEM
            
            SET @CustoTotal = @CustoVeiculo + @CustoMotorista + @CustoOperador + @CustoLavador + @CustoCombustivel
            
            -- KM Médio
            SELECT @ViagensComKm = COUNT(*)
            FROM Viagem
            WHERE CAST(COALESCE(DataInicialNormalizada, DataInicial) AS DATE) = @DataAtual
              AND Status = 'Realizada'
              AND COALESCE(KmInicialNormalizado, KmInicial) IS NOT NULL 
              AND COALESCE(KmFinalNormalizado, KmFinal) IS NOT NULL
              AND COALESCE(KmFinalNormalizado, KmFinal) >= COALESCE(KmInicialNormalizado, KmInicial)
              AND (COALESCE(KmFinalNormalizado, KmFinal) - COALESCE(KmInicialNormalizado, KmInicial)) <= @KM_MAXIMO_POR_VIAGEM
            
            SET @QuilometragemMedia = CASE WHEN @ViagensComKm > 0 THEN @QuilometragemTotal / @ViagensComKm ELSE 0 END
            
            -- =============================================================
            -- GERAR JSONs (APENAS VIAGENS REALIZADAS)
            -- =============================================================
            
            -- Viagens por Status
            SELECT @ViagensPorStatusJson = (
                SELECT Status as status, COUNT(*) as totalViagens
                FROM Viagem
                WHERE CAST(COALESCE(DataInicialNormalizada, DataInicial) AS DATE) = @DataAtual
                  AND Status IS NOT NULL
                GROUP BY Status
                FOR JSON PATH
            )
            
            -- Viagens por Motorista
            SELECT @ViagensPorMotoristaJson = (
                SELECT m.Nome as motorista, COUNT(*) as totalViagens
                FROM Viagem v
                INNER JOIN Motorista m ON v.MotoristaId = m.MotoristaId
                WHERE CAST(COALESCE(v.DataInicialNormalizada, v.DataInicial) AS DATE) = @DataAtual
                  AND v.Status = 'Realizada'
                GROUP BY m.Nome
                FOR JSON PATH
            )
            
            -- Viagens por Veículo
            SELECT @ViagensPorVeiculoJson = (
                SELECT 
                    vv.Placa + ' (' + 
                        CASE 
                            WHEN CHARINDEX('(', vv.MarcaModelo) > 1 
                            THEN RTRIM(LEFT(vv.MarcaModelo, CHARINDEX('(', vv.MarcaModelo) - 1))
                            ELSE vv.MarcaModelo 
                        END + ')' as veiculo,
                    COUNT(*) as totalViagens
                FROM Viagem v
                INNER JOIN ViewVeiculos vv ON v.VeiculoId = vv.VeiculoId
                WHERE CAST(COALESCE(v.DataInicialNormalizada, v.DataInicial) AS DATE) = @DataAtual
                  AND v.Status = 'Realizada'
                GROUP BY vv.Placa, vv.MarcaModelo
                FOR JSON PATH
            )
            
            -- Viagens por Finalidade
            SELECT @ViagensPorFinalidadeJson = (
                SELECT Finalidade as finalidade, COUNT(*) as totalViagens
                FROM Viagem
                WHERE CAST(COALESCE(DataInicialNormalizada, DataInicial) AS DATE) = @DataAtual
                  AND Status = 'Realizada'
                  AND Finalidade IS NOT NULL AND Finalidade <> ''
                GROUP BY Finalidade
                FOR JSON PATH
            )
            
            -- Viagens por Requisitante
            SELECT @ViagensPorRequisitanteJson = (
                SELECT r.Nome as requisitante, COUNT(*) as totalViagens
                FROM Viagem v
                INNER JOIN Requisitante r ON v.RequisitanteId = r.RequisitanteId
                WHERE CAST(COALESCE(v.DataInicialNormalizada, v.DataInicial) AS DATE) = @DataAtual
                  AND v.Status = 'Realizada'
                GROUP BY r.Nome
                FOR JSON PATH
            )
            
            -- Viagens por Setor
            SELECT @ViagensPorSetorJson = (
                SELECT s.Nome as setor, COUNT(*) as totalViagens
                FROM Viagem v
                INNER JOIN SetorSolicitante s ON v.SetorSolicitanteId = s.SetorSolicitanteId
                WHERE CAST(COALESCE(v.DataInicialNormalizada, v.DataInicial) AS DATE) = @DataAtual
                  AND v.Status = 'Realizada'
                GROUP BY s.Nome
                FOR JSON PATH
            )
            
            -- Custos por Motorista
            SELECT @CustosPorMotoristaJson = (
                SELECT 
                    m.Nome as motorista,
                    SUM(ISNULL(v.CustoMotorista, 0) + ISNULL(v.CustoVeiculo, 0) + 
                        ISNULL(v.CustoOperador, 0) + ISNULL(v.CustoLavador, 0) +
                        CASE WHEN COALESCE(v.KmInicialNormalizado, v.KmInicial) IS NOT NULL 
                                  AND COALESCE(v.KmFinalNormalizado, v.KmFinal) IS NOT NULL 
                                  AND COALESCE(v.KmFinalNormalizado, v.KmFinal) >= COALESCE(v.KmInicialNormalizado, v.KmInicial)
                                  AND (COALESCE(v.KmFinalNormalizado, v.KmFinal) - COALESCE(v.KmInicialNormalizado, v.KmInicial)) <= @KM_MAXIMO_POR_VIAGEM 
                             THEN ISNULL(v.CustoCombustivel, 0) ELSE 0 END
                    ) as custoTotal
                FROM Viagem v
                INNER JOIN Motorista m ON v.MotoristaId = m.MotoristaId
                WHERE CAST(COALESCE(v.DataInicialNormalizada, v.DataInicial) AS DATE) = @DataAtual
                  AND v.Status = 'Realizada'
                GROUP BY m.Nome
                HAVING SUM(ISNULL(v.CustoMotorista, 0) + ISNULL(v.CustoVeiculo, 0) + 
                          ISNULL(v.CustoOperador, 0) + ISNULL(v.CustoLavador, 0) +
                          CASE WHEN COALESCE(v.KmInicialNormalizado, v.KmInicial) IS NOT NULL 
                                    AND COALESCE(v.KmFinalNormalizado, v.KmFinal) IS NOT NULL 
                                    AND COALESCE(v.KmFinalNormalizado, v.KmFinal) >= COALESCE(v.KmInicialNormalizado, v.KmInicial)
                                    AND (COALESCE(v.KmFinalNormalizado, v.KmFinal) - COALESCE(v.KmInicialNormalizado, v.KmInicial)) <= @KM_MAXIMO_POR_VIAGEM 
                               THEN ISNULL(v.CustoCombustivel, 0) ELSE 0 END) > 0
                FOR JSON PATH
            )
            
            -- Custos por Veículo
            SELECT @CustosPorVeiculoJson = (
                SELECT 
                    vv.Placa + ' (' + 
                        CASE 
                            WHEN CHARINDEX('(', vv.MarcaModelo) > 1 
                            THEN RTRIM(LEFT(vv.MarcaModelo, CHARINDEX('(', vv.MarcaModelo) - 1))
                            ELSE vv.MarcaModelo 
                        END + ')' as veiculo,
                    SUM(ISNULL(v.CustoMotorista, 0) + ISNULL(v.CustoVeiculo, 0) + 
                        ISNULL(v.CustoOperador, 0) + ISNULL(v.CustoLavador, 0) +
                        CASE WHEN COALESCE(v.KmInicialNormalizado, v.KmInicial) IS NOT NULL 
                                  AND COALESCE(v.KmFinalNormalizado, v.KmFinal) IS NOT NULL 
                                  AND COALESCE(v.KmFinalNormalizado, v.KmFinal) >= COALESCE(v.KmInicialNormalizado, v.KmInicial)
                                  AND (COALESCE(v.KmFinalNormalizado, v.KmFinal) - COALESCE(v.KmInicialNormalizado, v.KmInicial)) <= @KM_MAXIMO_POR_VIAGEM 
                             THEN ISNULL(v.CustoCombustivel, 0) ELSE 0 END
                    ) as custoTotal
                FROM Viagem v
                INNER JOIN ViewVeiculos vv ON v.VeiculoId = vv.VeiculoId
                WHERE CAST(COALESCE(v.DataInicialNormalizada, v.DataInicial) AS DATE) = @DataAtual
                  AND v.Status = 'Realizada'
                GROUP BY vv.Placa, vv.MarcaModelo
                HAVING SUM(ISNULL(v.CustoMotorista, 0) + ISNULL(v.CustoVeiculo, 0) + 
                          ISNULL(v.CustoOperador, 0) + ISNULL(v.CustoLavador, 0) +
                          CASE WHEN COALESCE(v.KmInicialNormalizado, v.KmInicial) IS NOT NULL 
                                    AND COALESCE(v.KmFinalNormalizado, v.KmFinal) IS NOT NULL 
                                    AND COALESCE(v.KmFinalNormalizado, v.KmFinal) >= COALESCE(v.KmInicialNormalizado, v.KmInicial)
                                    AND (COALESCE(v.KmFinalNormalizado, v.KmFinal) - COALESCE(v.KmInicialNormalizado, v.KmInicial)) <= @KM_MAXIMO_POR_VIAGEM 
                               THEN ISNULL(v.CustoCombustivel, 0) ELSE 0 END) > 0
                FOR JSON PATH
            )
            
            -- KM por Veículo
            SELECT @KmPorVeiculoJson = (
                SELECT 
                    vv.Placa + ' (' + 
                        CASE 
                            WHEN CHARINDEX('(', vv.MarcaModelo) > 1 
                            THEN RTRIM(LEFT(vv.MarcaModelo, CHARINDEX('(', vv.MarcaModelo) - 1))
                            ELSE vv.MarcaModelo 
                        END + ')' as veiculo,
                    SUM(COALESCE(v.KmFinalNormalizado, v.KmFinal, 0) - COALESCE(v.KmInicialNormalizado, v.KmInicial, 0)) as kmTotal
                FROM Viagem v
                INNER JOIN ViewVeiculos vv ON v.VeiculoId = vv.VeiculoId
                WHERE CAST(COALESCE(v.DataInicialNormalizada, v.DataInicial) AS DATE) = @DataAtual
                  AND v.Status = 'Realizada'
                  AND COALESCE(v.KmInicialNormalizado, v.KmInicial) IS NOT NULL 
                  AND COALESCE(v.KmFinalNormalizado, v.KmFinal) IS NOT NULL
                  AND COALESCE(v.KmFinalNormalizado, v.KmFinal) >= COALESCE(v.KmInicialNormalizado, v.KmInicial)
                  AND (COALESCE(v.KmFinalNormalizado, v.KmFinal) - COALESCE(v.KmInicialNormalizado, v.KmInicial)) <= @KM_MAXIMO_POR_VIAGEM
                GROUP BY vv.Placa, vv.MarcaModelo
                HAVING SUM(COALESCE(v.KmFinalNormalizado, v.KmFinal, 0) - COALESCE(v.KmInicialNormalizado, v.KmInicial, 0)) > 0
                FOR JSON PATH
            )
            
            -- Custos por Tipo
            SELECT @CustosPorTipoJson = (
                SELECT tipo, valor
                FROM (
                    SELECT 
                        'Combustível' as tipo, 
                        SUM(CASE WHEN COALESCE(v.KmInicialNormalizado, v.KmInicial) IS NOT NULL 
                                      AND COALESCE(v.KmFinalNormalizado, v.KmFinal) IS NOT NULL 
                                      AND COALESCE(v.KmFinalNormalizado, v.KmFinal) >= COALESCE(v.KmInicialNormalizado, v.KmInicial)
                                      AND (COALESCE(v.KmFinalNormalizado, v.KmFinal) - COALESCE(v.KmInicialNormalizado, v.KmInicial)) <= @KM_MAXIMO_POR_VIAGEM 
                                 THEN ISNULL(v.CustoCombustivel, 0) ELSE 0 END) as valor
                    FROM Viagem v 
                    WHERE CAST(COALESCE(v.DataInicialNormalizada, v.DataInicial) AS DATE) = @DataAtual 
                      AND v.Status = 'Realizada'
                    UNION ALL
                    SELECT 'Veículo' as tipo, SUM(ISNULL(CustoVeiculo, 0)) as valor
                    FROM Viagem WHERE CAST(COALESCE(DataInicialNormalizada, DataInicial) AS DATE) = @DataAtual AND Status = 'Realizada'
                    UNION ALL
                    SELECT 'Motorista' as tipo, SUM(ISNULL(CustoMotorista, 0)) as valor
                    FROM Viagem WHERE CAST(COALESCE(DataInicialNormalizada, DataInicial) AS DATE) = @DataAtual AND Status = 'Realizada'
                    UNION ALL
                    SELECT 'Operador' as tipo, SUM(ISNULL(CustoOperador, 0)) as valor
                    FROM Viagem WHERE CAST(COALESCE(DataInicialNormalizada, DataInicial) AS DATE) = @DataAtual AND Status = 'Realizada'
                    UNION ALL
                    SELECT 'Lavador' as tipo, SUM(ISNULL(CustoLavador, 0)) as valor
                    FROM Viagem WHERE CAST(COALESCE(DataInicialNormalizada, DataInicial) AS DATE) = @DataAtual AND Status = 'Realizada'
                ) AS CustosTipo
                FOR JSON PATH
            )
            
            -- =============================================================
            -- INSERIR OU ATUALIZAR
            -- =============================================================
            
            IF EXISTS (SELECT 1 FROM ViagemEstatistica WHERE CAST(DataReferencia AS DATE) = @DataAtual)
            BEGIN
                UPDATE ViagemEstatistica
                SET 
                    TotalViagens = @TotalViagens,
                    ViagensFinalizadas = @ViagensFinalizadas,
                    ViagensEmAndamento = @ViagensEmAndamento,
                    ViagensAgendadas = @ViagensAgendadas,
                    ViagensCanceladas = @ViagensCanceladas,
                    CustoTotal = @CustoTotal,
                    CustoVeiculo = @CustoVeiculo,
                    CustoMotorista = @CustoMotorista,
                    CustoOperador = @CustoOperador,
                    CustoLavador = @CustoLavador,
                    CustoCombustivel = @CustoCombustivel,
                    QuilometragemTotal = @QuilometragemTotal,
                    QuilometragemMedia = @QuilometragemMedia,
                    ViagensPorStatusJson = @ViagensPorStatusJson,
                    ViagensPorMotoristaJson = @ViagensPorMotoristaJson,
                    ViagensPorVeiculoJson = @ViagensPorVeiculoJson,
                    ViagensPorFinalidadeJson = @ViagensPorFinalidadeJson,
                    ViagensPorRequisitanteJson = @ViagensPorRequisitanteJson,
                    ViagensPorSetorJson = @ViagensPorSetorJson,
                    CustosPorMotoristaJson = @CustosPorMotoristaJson,
                    CustosPorVeiculoJson = @CustosPorVeiculoJson,
                    KmPorVeiculoJson = @KmPorVeiculoJson,
                    CustosPorTipoJson = @CustosPorTipoJson,
                    DataAtualizacao = GETDATE()
                WHERE CAST(DataReferencia AS DATE) = @DataAtual
            END
            ELSE
            BEGIN
                INSERT INTO ViagemEstatistica (
                    DataReferencia, TotalViagens, ViagensFinalizadas, ViagensEmAndamento,
                    ViagensAgendadas, ViagensCanceladas, CustoTotal, CustoVeiculo,
                    CustoMotorista, CustoOperador, CustoLavador, CustoCombustivel,
                    QuilometragemTotal, QuilometragemMedia,
                    ViagensPorStatusJson, ViagensPorMotoristaJson, ViagensPorVeiculoJson,
                    ViagensPorFinalidadeJson, ViagensPorRequisitanteJson, ViagensPorSetorJson,
                    CustosPorMotoristaJson, CustosPorVeiculoJson, KmPorVeiculoJson, CustosPorTipoJson,
                    DataCriacao, DataAtualizacao
                )
                VALUES (
                    @DataAtual, @TotalViagens, @ViagensFinalizadas, @ViagensEmAndamento,
                    @ViagensAgendadas, @ViagensCanceladas, @CustoTotal, @CustoVeiculo,
                    @CustoMotorista, @CustoOperador, @CustoLavador, @CustoCombustivel,
                    @QuilometragemTotal, @QuilometragemMedia,
                    @ViagensPorStatusJson, @ViagensPorMotoristaJson, @ViagensPorVeiculoJson,
                    @ViagensPorFinalidadeJson, @ViagensPorRequisitanteJson, @ViagensPorSetorJson,
                    @CustosPorMotoristaJson, @CustosPorVeiculoJson, @KmPorVeiculoJson, @CustosPorTipoJson,
                    GETDATE(), GETDATE()
                )
            END
            
            -- Progresso
            IF @Contador % 100 = 0
                PRINT '         Processados ' + CAST(@Contador AS VARCHAR) + ' de ' + CAST(@TotalDias AS VARCHAR) + ' dias...'
            
            FETCH NEXT FROM cur_Datas INTO @DataAtual
        END
        
        CLOSE cur_Datas
        DEALLOCATE cur_Datas
        
        DROP TABLE #Datas
        
        PRINT '         Processamento concluído: ' + CAST(@Contador AS VARCHAR) + ' dias'
        
    END TRY
    BEGIN CATCH
        IF CURSOR_STATUS('local', 'cur_Datas') >= 0
        BEGIN
            CLOSE cur_Datas
            DEALLOCATE cur_Datas
        END
        
        IF OBJECT_ID('tempdb..#Datas') IS NOT NULL
            DROP TABLE #Datas
        
        DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE()
        PRINT '  [ERRO] ' + @ErrorMessage
        RAISERROR(@ErrorMessage, 16, 1)
    END CATCH
END
GO

PRINT '  [CREATE] Procedure sp_AtualizarViagemEstatistica criada'
PRINT ''

-- ============================================================================
-- RESUMO FINAL
-- ============================================================================

PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  SCRIPT 03 CONCLUÍDO COM SUCESSO!                                    ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''
PRINT '  Stored Procedure criada:'
PRINT '    ✓ sp_AtualizarViagemEstatistica'
PRINT ''
PRINT '  A SP usa COALESCE para priorizar campos normalizados:'
PRINT '    ✓ COALESCE(DataInicialNormalizada, DataInicial)'
PRINT '    ✓ COALESCE(KmInicialNormalizado, KmInicial)'
PRINT '    ✓ COALESCE(KmFinalNormalizado, KmFinal)'
PRINT ''
PRINT '  Filtros aplicados:'
PRINT '    ✓ Status = ''Realizada'' para custos e agregações'
PRINT '    ✓ KM máximo por viagem: 2000'
PRINT ''
PRINT '  Próximo passo: Execute o script 04_CargaInicial.sql'
PRINT ''
PRINT 'Fim: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT ''
GO
