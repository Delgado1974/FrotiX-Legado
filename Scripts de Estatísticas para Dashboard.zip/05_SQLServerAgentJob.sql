-- ============================================================================
-- FROTIX - 05: SQL SERVER AGENT JOB (Atualização Automática)
-- ============================================================================
-- Este script cria o Job que executa automaticamente a cada 30 minutos:
-- 1. Atualiza padrões de veículos (1x por dia às 01:00)
-- 2. Normaliza viagens dos últimos 30 dias
-- 3. Recalcula estatísticas dos últimos 30 dias
--
-- EXECUÇÃO: Após os scripts 01, 02, 03 e 04
-- REQUISITO: SQL Server Agent deve estar em execução
-- ============================================================================

USE msdb
GO

PRINT ''
PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  FROTIX - SCRIPT 05: SQL SERVER AGENT JOB                            ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''
PRINT 'Início: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT ''

-- ============================================================================
-- VERIFICAR PRÉ-REQUISITOS
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  VERIFICAÇÕES PRÉ-EXECUÇÃO'
PRINT '────────────────────────────────────────────────────────────────────────'

-- Verificar SP integrada
IF NOT EXISTS (SELECT * FROM FrotiX.sys.procedures WHERE name = 'sp_AtualizarEstatisticasIntegrado')
BEGIN
    PRINT '  [ERRO] SP sp_AtualizarEstatisticasIntegrado não existe!'
    RAISERROR('Execute o script 02 primeiro.', 16, 1)
    RETURN
END
PRINT '  [OK]  sp_AtualizarEstatisticasIntegrado encontrada'

PRINT ''

-- ============================================================================
-- REMOVER JOB EXISTENTE
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 1: Removendo Job existente'
PRINT '────────────────────────────────────────────────────────────────────────'

IF EXISTS (SELECT * FROM msdb.dbo.sysjobs WHERE name = N'FrotiX_AtualizarViagemEstatistica')
BEGIN
    EXEC msdb.dbo.sp_delete_job @job_name = N'FrotiX_AtualizarViagemEstatistica', @delete_unused_schedule = 1
    PRINT '  [DROP] Job FrotiX_AtualizarViagemEstatistica removido'
END
ELSE
BEGIN
    PRINT '  [INFO] Job não existia'
END

PRINT ''

-- ============================================================================
-- CRIAR O JOB
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 2: Criando Job'
PRINT '────────────────────────────────────────────────────────────────────────'

DECLARE @jobId BINARY(16)
DECLARE @ReturnCode INT = 0

EXEC @ReturnCode = msdb.dbo.sp_add_job 
    @job_name = N'FrotiX_AtualizarViagemEstatistica', 
    @enabled = 1, 
    @notify_level_eventlog = 0, 
    @notify_level_email = 0, 
    @notify_level_netsend = 0, 
    @notify_level_page = 0, 
    @delete_level = 0, 
    @description = N'Atualiza estatísticas de viagens do FrotiX a cada 30 minutos. Executa normalização de dados e cálculo de estatísticas para o Dashboard.', 
    @category_name = N'[Uncategorized (Local)]', 
    @owner_login_name = N'sa', 
    @job_id = @jobId OUTPUT

IF @ReturnCode <> 0 
BEGIN
    PRINT '  [ERRO] Falha ao criar o Job'
    RAISERROR('Erro ao criar Job', 16, 1)
    RETURN
END

PRINT '  [CREATE] Job criado com sucesso'

-- ============================================================================
-- CRIAR O STEP
-- ============================================================================

PRINT ''
PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 3: Criando Step do Job'
PRINT '────────────────────────────────────────────────────────────────────────'

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep 
    @job_id = @jobId, 
    @step_name = N'Executar Atualizacao Integrada', 
    @step_id = 1, 
    @cmdexec_success_code = 0, 
    @on_success_action = 1,
    @on_success_step_id = 0, 
    @on_fail_action = 2,
    @on_fail_step_id = 0, 
    @retry_attempts = 3, 
    @retry_interval = 5,
    @os_run_priority = 0, 
    @subsystem = N'TSQL', 
    @command = N'
-- ============================================
-- FrotiX - Job Integrado de Estatísticas
-- ============================================

USE FrotiX

PRINT ''Início: '' + CONVERT(VARCHAR(20), GETDATE(), 120)

-- Executa o procedimento integrado
EXEC sp_AtualizarEstatisticasIntegrado @DiasParaProcessar = 30

PRINT ''Fim: '' + CONVERT(VARCHAR(20), GETDATE(), 120)
', 
    @database_name = N'FrotiX', 
    @flags = 0

IF @ReturnCode <> 0 
BEGIN
    PRINT '  [ERRO] Falha ao criar o Step'
    RAISERROR('Erro ao criar Step', 16, 1)
    RETURN
END

PRINT '  [CREATE] Step criado: Executar Atualizacao Integrada'
PRINT '           - Retry: 3 tentativas, intervalo 5 min'

-- ============================================================================
-- CRIAR O SCHEDULE
-- ============================================================================

PRINT ''
PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 4: Criando Schedule'
PRINT '────────────────────────────────────────────────────────────────────────'

EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule 
    @job_id = @jobId, 
    @name = N'Cada_30_Minutos', 
    @enabled = 1, 
    @freq_type = 4,
    @freq_interval = 1,
    @freq_subday_type = 4,
    @freq_subday_interval = 30,
    @freq_relative_interval = 0, 
    @freq_recurrence_factor = 0, 
    @active_start_date = 20240101, 
    @active_end_date = 99991231, 
    @active_start_time = 0,
    @active_end_time = 235959

IF @ReturnCode <> 0 
BEGIN
    PRINT '  [ERRO] Falha ao criar o Schedule'
    RAISERROR('Erro ao criar Schedule', 16, 1)
    RETURN
END

PRINT '  [CREATE] Schedule criado: Cada_30_Minutos'
PRINT '           - Frequência: A cada 30 minutos'
PRINT '           - Horário: 00:00 às 23:59'

-- ============================================================================
-- ASSOCIAR AO SERVIDOR
-- ============================================================================

PRINT ''
PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 5: Associando ao servidor'
PRINT '────────────────────────────────────────────────────────────────────────'

EXEC @ReturnCode = msdb.dbo.sp_add_jobserver 
    @job_id = @jobId, 
    @server_name = N'(local)'

IF @ReturnCode <> 0 
BEGIN
    PRINT '  [ERRO] Falha ao associar ao servidor'
    RAISERROR('Erro ao associar Job ao servidor', 16, 1)
    RETURN
END

PRINT '  [OK]  Job associado ao servidor local'
PRINT ''

-- ============================================================================
-- RESUMO FINAL
-- ============================================================================

PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  SCRIPT 05 CONCLUÍDO COM SUCESSO!                                    ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''
PRINT '  JOB CRIADO:'
PRINT '  ────────────────────────────────────────────'
PRINT '    Nome: FrotiX_AtualizarViagemEstatistica'
PRINT '    Frequência: A cada 30 minutos'
PRINT '    Horário: 24 horas por dia'
PRINT '    Retentativas: 3 (intervalo 5 min)'
PRINT ''
PRINT '  O QUE O JOB FAZ:'
PRINT '  ────────────────────────────────────────────'
PRINT '    1. Atualiza padrões de veículos (apenas às 01:00)'
PRINT '    2. Normaliza viagens dos últimos 30 dias'
PRINT '    3. Recalcula estatísticas dos últimos 30 dias'
PRINT ''
PRINT '  COMANDOS ÚTEIS:'
PRINT '  ────────────────────────────────────────────'
PRINT '    Executar manualmente:'
PRINT '    EXEC msdb.dbo.sp_start_job @job_name = ''FrotiX_AtualizarViagemEstatistica'''
PRINT ''
PRINT '    Ver histórico:'
PRINT '    SELECT * FROM msdb.dbo.sysjobhistory'
PRINT '    WHERE job_id = (SELECT job_id FROM msdb.dbo.sysjobs'
PRINT '                    WHERE name = ''FrotiX_AtualizarViagemEstatistica'')'
PRINT '    ORDER BY run_date DESC, run_time DESC'
PRINT ''
PRINT '  Próximo passo: Execute o script 06_IndicesOtimizacao.sql'
PRINT ''
PRINT 'Fim: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT ''
GO

-- ============================================================================
-- EXECUTAR PRIMEIRA VEZ (TESTE)
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  EXECUTANDO JOB PELA PRIMEIRA VEZ (TESTE)'
PRINT '────────────────────────────────────────────────────────────────────────'

EXEC msdb.dbo.sp_start_job @job_name = N'FrotiX_AtualizarViagemEstatistica'
PRINT '  [START] Job iniciado!'
PRINT '          Verifique o resultado no histórico do SQL Server Agent.'
PRINT ''
GO
