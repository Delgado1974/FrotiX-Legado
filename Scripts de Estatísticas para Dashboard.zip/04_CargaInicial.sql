-- ============================================================================
-- FROTIX - 04: CARGA INICIAL (Normalização + Estatísticas)
-- ============================================================================
-- Este script executa a carga inicial completa:
-- 1. Calcula padrões de veículos (baseado em viagens e abastecimentos)
-- 2. Normaliza todas as viagens históricas
-- 3. Popula a tabela ViagemEstatistica
--
-- EXECUÇÃO: Após os scripts 01, 02 e 03
-- ATENÇÃO: Este script pode demorar vários minutos!
-- ============================================================================

USE FrotiX
GO

PRINT ''
PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  FROTIX - SCRIPT 04: CARGA INICIAL COMPLETA                          ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''
PRINT 'Início: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT ''

-- ============================================================================
-- VERIFICAÇÕES PRÉ-EXECUÇÃO
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  VERIFICAÇÕES PRÉ-EXECUÇÃO'
PRINT '────────────────────────────────────────────────────────────────────────'

DECLARE @Erro BIT = 0

-- Verificar tabela ViagemEstatistica
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'ViagemEstatistica')
BEGIN
    PRINT '  [ERRO] Tabela ViagemEstatistica não existe! Execute o script 01 primeiro.'
    SET @Erro = 1
END
ELSE
    PRINT '  [OK]  Tabela ViagemEstatistica'

-- Verificar tabela VeiculoPadraoViagem
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'VeiculoPadraoViagem')
BEGIN
    PRINT '  [ERRO] Tabela VeiculoPadraoViagem não existe! Execute o script 02 primeiro.'
    SET @Erro = 1
END
ELSE
    PRINT '  [OK]  Tabela VeiculoPadraoViagem'

-- Verificar campos normalizados
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Viagem') AND name = 'DataInicialNormalizada')
BEGIN
    PRINT '  [ERRO] Campos normalizados não existem! Execute o script 02 primeiro.'
    SET @Erro = 1
END
ELSE
    PRINT '  [OK]  Campos normalizados na Viagem'

-- Verificar SPs
IF NOT EXISTS (SELECT * FROM sys.procedures WHERE name = 'sp_AtualizarPadroesVeiculos')
BEGIN
    PRINT '  [ERRO] SP sp_AtualizarPadroesVeiculos não existe! Execute o script 02 primeiro.'
    SET @Erro = 1
END
ELSE
    PRINT '  [OK]  sp_AtualizarPadroesVeiculos'

IF NOT EXISTS (SELECT * FROM sys.procedures WHERE name = 'sp_NormalizarViagens')
BEGIN
    PRINT '  [ERRO] SP sp_NormalizarViagens não existe! Execute o script 02 primeiro.'
    SET @Erro = 1
END
ELSE
    PRINT '  [OK]  sp_NormalizarViagens'

IF NOT EXISTS (SELECT * FROM sys.procedures WHERE name = 'sp_AtualizarViagemEstatistica')
BEGIN
    PRINT '  [ERRO] SP sp_AtualizarViagemEstatistica não existe! Execute o script 03 primeiro.'
    SET @Erro = 1
END
ELSE
    PRINT '  [OK]  sp_AtualizarViagemEstatistica'

IF @Erro = 1
BEGIN
    RAISERROR('Verificações falharam. Corrija os erros acima e execute novamente.', 16, 1)
    RETURN
END

PRINT ''

-- ============================================================================
-- IDENTIFICAR PERÍODO
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  IDENTIFICAÇÃO DO PERÍODO'
PRINT '────────────────────────────────────────────────────────────────────────'

DECLARE @PrimeiraViagem DATE
DECLARE @UltimaViagem DATE
DECLARE @Hoje DATE = CAST(GETDATE() AS DATE)
DECLARE @TotalViagens INT

SELECT 
    @PrimeiraViagem = CAST(MIN(DataInicial) AS DATE),
    @UltimaViagem = CAST(MAX(DataInicial) AS DATE),
    @TotalViagens = COUNT(*)
FROM Viagem
WHERE DataInicial IS NOT NULL

IF @PrimeiraViagem IS NULL
BEGIN
    PRINT '  [AVISO] Nenhuma viagem encontrada no banco de dados.'
    RETURN
END

-- Limitar ao dia de hoje
IF @UltimaViagem > @Hoje
BEGIN
    PRINT '  [AVISO] Existem viagens com datas futuras (serão normalizadas)'
    SET @UltimaViagem = @Hoje
END

PRINT '  Primeira viagem: ' + CONVERT(VARCHAR(10), @PrimeiraViagem, 103)
PRINT '  Última viagem:   ' + CONVERT(VARCHAR(10), @UltimaViagem, 103)
PRINT '  Total de dias:   ' + CAST(DATEDIFF(DAY, @PrimeiraViagem, @UltimaViagem) + 1 AS VARCHAR)
PRINT '  Total de viagens: ' + CAST(@TotalViagens AS VARCHAR)
PRINT ''

DECLARE @InicioTotal DATETIME = GETDATE()

-- ============================================================================
-- ETAPA 1: CALCULAR PADRÕES DE VEÍCULOS
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 1/3: PADRÕES DE VEÍCULOS'
PRINT '────────────────────────────────────────────────────────────────────────'

DECLARE @InicioEtapa DATETIME = GETDATE()

EXEC sp_AtualizarPadroesVeiculos

DECLARE @DuracaoEtapa INT = DATEDIFF(SECOND, @InicioEtapa, GETDATE())
PRINT '  [TEMPO] Duração: ' + CAST(@DuracaoEtapa AS VARCHAR) + ' segundos'
PRINT ''

-- ============================================================================
-- ETAPA 2: NORMALIZAR VIAGENS
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 2/3: NORMALIZAÇÃO DE VIAGENS'
PRINT '────────────────────────────────────────────────────────────────────────'

SET @InicioEtapa = GETDATE()

-- Calcular dias desde a primeira viagem
DECLARE @DiasHistorico INT = DATEDIFF(DAY, @PrimeiraViagem, @Hoje) + 30

EXEC sp_NormalizarViagens 
    @DiasParaProcessar = @DiasHistorico, 
    @ForcarReprocessamento = 1

SET @DuracaoEtapa = DATEDIFF(SECOND, @InicioEtapa, GETDATE())
PRINT '  [TEMPO] Duração: ' + CAST(@DuracaoEtapa AS VARCHAR) + ' segundos'
PRINT ''

-- Mostrar resumo
DECLARE @ViagensCorrigidas INT, @ViagensNormais INT
SELECT @ViagensCorrigidas = COUNT(*) FROM Viagem WHERE FoiNormalizada = 1 AND DataNormalizacao IS NOT NULL
SELECT @ViagensNormais = COUNT(*) FROM Viagem WHERE FoiNormalizada = 0 AND DataNormalizacao IS NOT NULL

PRINT '  [RESUMO] Viagens processadas:'
PRINT '           - Normais (sem correção): ' + CAST(@ViagensNormais AS VARCHAR)
PRINT '           - Corrigidas: ' + CAST(@ViagensCorrigidas AS VARCHAR)
PRINT ''

-- ============================================================================
-- ETAPA 3: CALCULAR ESTATÍSTICAS
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 3/3: ESTATÍSTICAS (ViagemEstatistica)'
PRINT '────────────────────────────────────────────────────────────────────────'

SET @InicioEtapa = GETDATE()

-- Limpar tabela
DECLARE @RegAntigos INT
SELECT @RegAntigos = COUNT(*) FROM ViagemEstatistica
DELETE FROM ViagemEstatistica
PRINT '  [LIMPAR] Tabela ViagemEstatistica limpa (' + CAST(@RegAntigos AS VARCHAR) + ' registros removidos)'

-- Executar carga
EXEC sp_AtualizarViagemEstatistica 
    @DataInicio = @PrimeiraViagem, 
    @DataFim = @Hoje

SET @DuracaoEtapa = DATEDIFF(SECOND, @InicioEtapa, GETDATE())
PRINT '  [TEMPO] Duração: ' + CAST(@DuracaoEtapa AS VARCHAR) + ' segundos'
PRINT ''

-- ============================================================================
-- RESUMO FINAL
-- ============================================================================

DECLARE @FimTotal DATETIME = GETDATE()
DECLARE @DuracaoTotal INT = DATEDIFF(SECOND, @InicioTotal, @FimTotal)

PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  SCRIPT 04 CONCLUÍDO COM SUCESSO!                                    ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''

-- Estatísticas finais
DECLARE @TotalRegistros INT, @TotalViagensEstat INT
DECLARE @CustoTotalGeral DECIMAL(18,2), @KmTotalGeral DECIMAL(18,2)

SELECT 
    @TotalRegistros = COUNT(*),
    @TotalViagensEstat = SUM(TotalViagens),
    @CustoTotalGeral = SUM(CustoTotal),
    @KmTotalGeral = SUM(QuilometragemTotal)
FROM ViagemEstatistica

PRINT '  ESTATÍSTICAS GERADAS:'
PRINT '  ────────────────────────────────────────────'
PRINT '    Registros criados (dias): ' + CAST(@TotalRegistros AS VARCHAR)
PRINT '    Total de viagens:         ' + CAST(@TotalViagensEstat AS VARCHAR)
PRINT '    Custo total:              R$ ' + CAST(CAST(@CustoTotalGeral AS DECIMAL(18,2)) AS VARCHAR)
PRINT '    KM total:                 ' + CAST(CAST(@KmTotalGeral AS INT) AS VARCHAR) + ' km'
PRINT ''

PRINT '  PADRÕES DE VEÍCULOS:'
PRINT '  ────────────────────────────────────────────'
DECLARE @TotalPadroes INT, @ComAbastecimento INT
SELECT @TotalPadroes = COUNT(*) FROM VeiculoPadraoViagem
SELECT @ComAbastecimento = COUNT(*) FROM VeiculoPadraoViagem WHERE MediaKmPorDia IS NOT NULL
PRINT '    Veículos com padrão: ' + CAST(@TotalPadroes AS VARCHAR)
PRINT '    Com dados abastecimento: ' + CAST(@ComAbastecimento AS VARCHAR)
PRINT ''

PRINT '  NORMALIZAÇÕES:'
PRINT '  ────────────────────────────────────────────'
PRINT '    Viagens corrigidas: ' + CAST(@ViagensCorrigidas AS VARCHAR)
PRINT ''

PRINT '  TEMPO DE EXECUÇÃO:'
PRINT '  ────────────────────────────────────────────'
PRINT '    Total: ' + CAST(@DuracaoTotal AS VARCHAR) + ' segundos (' + 
      CAST(@DuracaoTotal / 60 AS VARCHAR) + ' min ' + CAST(@DuracaoTotal % 60 AS VARCHAR) + ' seg)'
PRINT ''
PRINT '  Próximo passo: Execute o script 05_SQLServerAgentJob.sql'
PRINT ''
PRINT 'Fim: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT ''
GO
