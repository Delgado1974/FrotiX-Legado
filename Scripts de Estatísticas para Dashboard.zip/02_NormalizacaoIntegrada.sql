-- ============================================================================
-- FROTIX - 02: SISTEMA DE NORMALIZAÇÃO DE DADOS
-- ============================================================================
-- Este script:
-- 1. Adiciona campos normalizados na tabela Viagem
-- 2. Cria tabela VeiculoPadraoViagem (padrões de uso por veículo)
-- 3. Cria procedures de normalização de datas/km
-- 4. Cria procedure integrada que normaliza E calcula estatísticas
--
-- EXECUÇÃO: Após o script 01
-- ============================================================================

USE FrotiX
GO

PRINT ''
PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  FROTIX - SCRIPT 02: NORMALIZAÇÃO INTEGRADA                          ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''
PRINT 'Início: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT ''

-- ============================================================================
-- PARTE 1: CAMPOS NORMALIZADOS NA TABELA VIAGEM
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  PARTE 1: Campos Normalizados na Tabela Viagem'
PRINT '────────────────────────────────────────────────────────────────────────'

-- DataInicialNormalizada
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Viagem') AND name = 'DataInicialNormalizada')
BEGIN
    ALTER TABLE Viagem ADD DataInicialNormalizada DATETIME2 NULL
    PRINT '  [ADD] Campo DataInicialNormalizada adicionado'
END
ELSE
    PRINT '  [OK]  Campo DataInicialNormalizada já existe'

-- DataFinalNormalizada
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Viagem') AND name = 'DataFinalNormalizada')
BEGIN
    ALTER TABLE Viagem ADD DataFinalNormalizada DATETIME2 NULL
    PRINT '  [ADD] Campo DataFinalNormalizada adicionado'
END
ELSE
    PRINT '  [OK]  Campo DataFinalNormalizada já existe'

-- HoraInicioNormalizada
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Viagem') AND name = 'HoraInicioNormalizada')
BEGIN
    ALTER TABLE Viagem ADD HoraInicioNormalizada TIME NULL
    PRINT '  [ADD] Campo HoraInicioNormalizada adicionado'
END
ELSE
    PRINT '  [OK]  Campo HoraInicioNormalizada já existe'

-- HoraFimNormalizada
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Viagem') AND name = 'HoraFimNormalizada')
BEGIN
    ALTER TABLE Viagem ADD HoraFimNormalizada TIME NULL
    PRINT '  [ADD] Campo HoraFimNormalizada adicionado'
END
ELSE
    PRINT '  [OK]  Campo HoraFimNormalizada já existe'

-- MinutosNormalizado
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Viagem') AND name = 'MinutosNormalizado')
BEGIN
    ALTER TABLE Viagem ADD MinutosNormalizado INT NULL
    PRINT '  [ADD] Campo MinutosNormalizado adicionado'
END
ELSE
    PRINT '  [OK]  Campo MinutosNormalizado já existe'

-- KmInicialNormalizado
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Viagem') AND name = 'KmInicialNormalizado')
BEGIN
    ALTER TABLE Viagem ADD KmInicialNormalizado DECIMAL(18,2) NULL
    PRINT '  [ADD] Campo KmInicialNormalizado adicionado'
END
ELSE
    PRINT '  [OK]  Campo KmInicialNormalizado já existe'

-- KmFinalNormalizado
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Viagem') AND name = 'KmFinalNormalizado')
BEGIN
    ALTER TABLE Viagem ADD KmFinalNormalizado DECIMAL(18,2) NULL
    PRINT '  [ADD] Campo KmFinalNormalizado adicionado'
END
ELSE
    PRINT '  [OK]  Campo KmFinalNormalizado já existe'

-- FoiNormalizada (flag)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Viagem') AND name = 'FoiNormalizada')
BEGIN
    ALTER TABLE Viagem ADD FoiNormalizada BIT DEFAULT 0
    PRINT '  [ADD] Campo FoiNormalizada adicionado'
END
ELSE
    PRINT '  [OK]  Campo FoiNormalizada já existe'

-- TipoNormalizacao
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Viagem') AND name = 'TipoNormalizacao')
BEGIN
    ALTER TABLE Viagem ADD TipoNormalizacao NVARCHAR(500) NULL
    PRINT '  [ADD] Campo TipoNormalizacao adicionado'
END
ELSE
    PRINT '  [OK]  Campo TipoNormalizacao já existe'

-- DataNormalizacao
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Viagem') AND name = 'DataNormalizacao')
BEGIN
    ALTER TABLE Viagem ADD DataNormalizacao DATETIME2 NULL
    PRINT '  [ADD] Campo DataNormalizacao adicionado'
END
ELSE
    PRINT '  [OK]  Campo DataNormalizacao já existe'

PRINT ''
GO

-- ============================================================================
-- PARTE 2: TABELA VEICULO PADRAO VIAGEM (DROP + CREATE)
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  PARTE 2: Tabela VeiculoPadraoViagem'
PRINT '────────────────────────────────────────────────────────────────────────'

-- DROP tabela e índices
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_VeiculoPadraoViagem_TipoUso' AND object_id = OBJECT_ID('VeiculoPadraoViagem'))
BEGIN
    DROP INDEX IX_VeiculoPadraoViagem_TipoUso ON VeiculoPadraoViagem
    PRINT '  [DROP] Índice IX_VeiculoPadraoViagem_TipoUso removido'
END

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_VeiculoPadraoViagem_VeiculoId' AND object_id = OBJECT_ID('VeiculoPadraoViagem'))
BEGIN
    DROP INDEX IX_VeiculoPadraoViagem_VeiculoId ON VeiculoPadraoViagem
    PRINT '  [DROP] Índice IX_VeiculoPadraoViagem_VeiculoId removido'
END

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'VeiculoPadraoViagem')
BEGIN
    DECLARE @RegVeiculoPadrao INT
    SELECT @RegVeiculoPadrao = COUNT(*) FROM VeiculoPadraoViagem
    DROP TABLE VeiculoPadraoViagem
    PRINT '  [DROP] Tabela VeiculoPadraoViagem removida (' + CAST(@RegVeiculoPadrao AS VARCHAR) + ' registros)'
END
ELSE
BEGIN
    PRINT '  [INFO] Tabela VeiculoPadraoViagem não existia'
END

-- CREATE tabela
CREATE TABLE VeiculoPadraoViagem (
    VeiculoPadraoViagemId INT IDENTITY(1,1) PRIMARY KEY,
    VeiculoId UNIQUEIDENTIFIER NOT NULL,
    
    -- Estatísticas de duração (em minutos)
    MediaDuracaoMinutos DECIMAL(18,2) NULL,
    DesvioPadraoDuracaoMinutos DECIMAL(18,2) NULL,
    MinDuracaoMinutos INT NULL,
    MaxDuracaoNormalMinutos INT NULL,
    
    -- Estatísticas de KM baseadas em VIAGENS
    MediaKmPorViagem DECIMAL(18,2) NULL,
    DesvioPadraoKm DECIMAL(18,2) NULL,
    MaxKmNormalPorViagem DECIMAL(18,2) NULL,
    
    -- Estatísticas de KM baseadas em ABASTECIMENTO (mais confiável!)
    MediaKmPorDia DECIMAL(18,2) NULL,
    MediaKmEntreAbastecimentos DECIMAL(18,2) NULL,
    MediaDiasEntreAbastecimentos DECIMAL(18,2) NULL,
    TotalAbastecimentosAnalisados INT DEFAULT 0,
    
    -- Contadores
    TotalViagensAnalisadas INT DEFAULT 0,
    
    -- Classificação do veículo
    TipoUso VARCHAR(50) NULL,
    
    -- Auditoria
    DataAtualizacao DATETIME2 DEFAULT GETDATE(),
    
    CONSTRAINT FK_VeiculoPadraoViagem_Veiculo FOREIGN KEY (VeiculoId) 
        REFERENCES Veiculo(VeiculoId)
)

PRINT '  [CREATE] Tabela VeiculoPadraoViagem criada'
PRINT '           - Estatísticas de duração (media, desvio, min, max)'
PRINT '           - Estatísticas de KM por viagem'
PRINT '           - Estatísticas de KM por abastecimento (MediaKmPorDia)'
PRINT '           - Classificação: DIARIO, MISTO, LONGA_DURACAO'

-- Índice único por veículo
CREATE UNIQUE NONCLUSTERED INDEX IX_VeiculoPadraoViagem_VeiculoId 
    ON VeiculoPadraoViagem(VeiculoId)
PRINT '  [CREATE] Índice IX_VeiculoPadraoViagem_VeiculoId (UNIQUE)'

-- Índice por tipo de uso
CREATE NONCLUSTERED INDEX IX_VeiculoPadraoViagem_TipoUso 
    ON VeiculoPadraoViagem(TipoUso)
    INCLUDE (MediaDuracaoMinutos, MaxDuracaoNormalMinutos, MediaKmPorDia)
PRINT '  [CREATE] Índice IX_VeiculoPadraoViagem_TipoUso'

PRINT ''
GO

-- ============================================================================
-- PARTE 3: STORED PROCEDURE - ATUALIZAR PADRÕES DE VEÍCULOS
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  PARTE 3: SP sp_AtualizarPadroesVeiculos'
PRINT '────────────────────────────────────────────────────────────────────────'

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'sp_AtualizarPadroesVeiculos')
BEGIN
    DROP PROCEDURE sp_AtualizarPadroesVeiculos
    PRINT '  [DROP] Procedure sp_AtualizarPadroesVeiculos removida'
END
GO

CREATE PROCEDURE sp_AtualizarPadroesVeiculos
AS
BEGIN
    SET NOCOUNT ON
    
    PRINT '  [EXEC] Calculando padrões de veículos...'
    
    -- Limpar e recalcular
    DELETE FROM VeiculoPadraoViagem
    
    -- =========================================================================
    -- Estatísticas baseadas em VIAGENS + ABASTECIMENTO
    -- =========================================================================
    ;WITH EstatisticasViagem AS (
        SELECT 
            v.VeiculoId,
            COUNT(*) as TotalViagens,
            
            AVG(CASE 
                WHEN v.Status = 'Realizada' AND v.Minutos > 0 AND v.Minutos < 43200
                THEN CAST(v.Minutos AS FLOAT) ELSE NULL 
            END) as MediaMinutos,
            
            STDEV(CASE 
                WHEN v.Status = 'Realizada' AND v.Minutos > 0 AND v.Minutos < 43200
                THEN CAST(v.Minutos AS FLOAT) ELSE NULL 
            END) as DesvioPadraoMinutos,
            
            MIN(CASE 
                WHEN v.Status = 'Realizada' AND v.Minutos > 0 AND v.Minutos < 43200
                THEN v.Minutos ELSE NULL 
            END) as MinMinutos,
            
            AVG(CASE 
                WHEN v.Status = 'Realizada' 
                     AND v.KmInicial IS NOT NULL AND v.KmFinal IS NOT NULL
                     AND v.KmFinal >= v.KmInicial AND (v.KmFinal - v.KmInicial) <= 2000
                THEN CAST(v.KmFinal - v.KmInicial AS FLOAT) ELSE NULL 
            END) as MediaKm,
            
            STDEV(CASE 
                WHEN v.Status = 'Realizada' 
                     AND v.KmInicial IS NOT NULL AND v.KmFinal IS NOT NULL
                     AND v.KmFinal >= v.KmInicial AND (v.KmFinal - v.KmInicial) <= 2000
                THEN CAST(v.KmFinal - v.KmInicial AS FLOAT) ELSE NULL 
            END) as DesvioPadraoKm
            
        FROM Viagem v
        WHERE v.VeiculoId IS NOT NULL
        GROUP BY v.VeiculoId
        HAVING COUNT(*) >= 3
    ),
    AbastecimentoOrdenado AS (
        SELECT 
            VeiculoId,
            DataHora,
            Hodometro,
            KmRodado,
            LAG(DataHora) OVER (PARTITION BY VeiculoId ORDER BY DataHora) as DataHoraAnterior,
            LAG(Hodometro) OVER (PARTITION BY VeiculoId ORDER BY DataHora) as HodometroAnterior
        FROM Abastecimento
        WHERE Hodometro > 0
    ),
    EstatisticasAbastecimento AS (
        SELECT 
            VeiculoId,
            COUNT(*) as TotalAbastecimentos,
            
            AVG(CASE 
                WHEN KmRodado > 0 AND KmRodado <= 2000 THEN CAST(KmRodado AS FLOAT)
                WHEN HodometroAnterior IS NOT NULL 
                     AND Hodometro > HodometroAnterior 
                     AND (Hodometro - HodometroAnterior) <= 2000
                THEN CAST(Hodometro - HodometroAnterior AS FLOAT)
                ELSE NULL
            END) as MediaKmEntreAbastecimentos,
            
            AVG(CASE 
                WHEN DataHoraAnterior IS NOT NULL 
                     AND DATEDIFF(DAY, DataHoraAnterior, DataHora) BETWEEN 1 AND 60
                THEN CAST(DATEDIFF(DAY, DataHoraAnterior, DataHora) AS FLOAT)
                ELSE NULL
            END) as MediaDiasEntreAbastecimentos
            
        FROM AbastecimentoOrdenado
        GROUP BY VeiculoId
        HAVING COUNT(*) >= 3
    )
    INSERT INTO VeiculoPadraoViagem (
        VeiculoId, 
        MediaDuracaoMinutos, DesvioPadraoDuracaoMinutos,
        MinDuracaoMinutos, MaxDuracaoNormalMinutos,
        MediaKmPorViagem, DesvioPadraoKm, MaxKmNormalPorViagem,
        TotalViagensAnalisadas,
        MediaKmPorDia, MediaKmEntreAbastecimentos, MediaDiasEntreAbastecimentos,
        TotalAbastecimentosAnalisados,
        TipoUso
    )
    SELECT 
        COALESCE(ev.VeiculoId, ea.VeiculoId) as VeiculoId,
        ev.MediaMinutos,
        ev.DesvioPadraoMinutos,
        ev.MinMinutos,
        CAST(CASE 
            WHEN ev.MediaMinutos <= 480 THEN GREATEST(ev.MediaMinutos + 3 * ISNULL(ev.DesvioPadraoMinutos, 60), 1440)
            ELSE ev.MediaMinutos + 3 * ISNULL(ev.DesvioPadraoMinutos, 60)
        END AS INT),
        ev.MediaKm,
        ev.DesvioPadraoKm,
        GREATEST(ISNULL(ev.MediaKm, 100) + 3 * ISNULL(ev.DesvioPadraoKm, 50), 500),
        ISNULL(ev.TotalViagens, 0),
        CASE 
            WHEN ea.MediaDiasEntreAbastecimentos > 0 
            THEN ea.MediaKmEntreAbastecimentos / ea.MediaDiasEntreAbastecimentos
            ELSE NULL
        END as MediaKmPorDia,
        ea.MediaKmEntreAbastecimentos,
        ea.MediaDiasEntreAbastecimentos,
        ISNULL(ea.TotalAbastecimentos, 0),
        CASE 
            WHEN ev.MediaMinutos <= 480 THEN 'DIARIO'
            WHEN ev.MediaMinutos <= 4320 THEN 'MISTO'
            ELSE 'LONGA_DURACAO'
        END
    FROM EstatisticasViagem ev
    FULL OUTER JOIN EstatisticasAbastecimento ea ON ev.VeiculoId = ea.VeiculoId
    WHERE COALESCE(ev.MediaMinutos, ea.MediaKmEntreAbastecimentos) IS NOT NULL
    
    DECLARE @Total INT = @@ROWCOUNT
    PRINT '         Padrões calculados para ' + CAST(@Total AS VARCHAR) + ' veículos'
    
    -- Resumo por tipo
    DECLARE @Diario INT, @Misto INT, @Longa INT, @ComAbast INT
    SELECT @Diario = COUNT(*) FROM VeiculoPadraoViagem WHERE TipoUso = 'DIARIO'
    SELECT @Misto = COUNT(*) FROM VeiculoPadraoViagem WHERE TipoUso = 'MISTO'
    SELECT @Longa = COUNT(*) FROM VeiculoPadraoViagem WHERE TipoUso = 'LONGA_DURACAO'
    SELECT @ComAbast = COUNT(*) FROM VeiculoPadraoViagem WHERE MediaKmPorDia IS NOT NULL
    
    PRINT '         - DIARIO: ' + CAST(@Diario AS VARCHAR)
    PRINT '         - MISTO: ' + CAST(@Misto AS VARCHAR)
    PRINT '         - LONGA_DURACAO: ' + CAST(@Longa AS VARCHAR)
    PRINT '         - Com dados de abastecimento: ' + CAST(@ComAbast AS VARCHAR)
    
    RETURN @Total
END
GO

PRINT '  [CREATE] Procedure sp_AtualizarPadroesVeiculos criada'
PRINT ''
GO

-- ============================================================================
-- PARTE 4: STORED PROCEDURE - NORMALIZAR VIAGENS
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  PARTE 4: SP sp_NormalizarViagens'
PRINT '────────────────────────────────────────────────────────────────────────'

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'sp_NormalizarViagens')
BEGIN
    DROP PROCEDURE sp_NormalizarViagens
    PRINT '  [DROP] Procedure sp_NormalizarViagens removida'
END
GO

CREATE PROCEDURE sp_NormalizarViagens
    @DiasParaProcessar INT = 30,
    @ForcarReprocessamento BIT = 0
AS
BEGIN
    SET NOCOUNT ON
    
    DECLARE @Hoje DATE = GETDATE()
    DECLARE @AnoAtual INT = YEAR(GETDATE())
    DECLARE @DataLimite DATE = DATEADD(DAY, -@DiasParaProcessar, @Hoje)
    DECLARE @TotalNormalizadas INT = 0
    DECLARE @KM_MAXIMO_VIAGEM INT = 2000
    
    PRINT '  [EXEC] Normalizando viagens dos últimos ' + CAST(@DiasParaProcessar AS VARCHAR) + ' dias...'
    
    -- =========================================================================
    -- PASSO 1: Viagens sem anomalias - copiar valores originais
    -- =========================================================================
    UPDATE v
    SET 
        DataInicialNormalizada = v.DataInicial,
        DataFinalNormalizada = COALESCE(v.DataFinal, v.DataInicial),
        HoraInicioNormalizada = CAST(v.HoraInicio AS TIME),
        HoraFimNormalizada = CAST(v.HoraFim AS TIME),
        MinutosNormalizado = CASE 
            WHEN v.Minutos > 0 AND v.Minutos < 43200 THEN v.Minutos 
            ELSE NULL 
        END,
        KmInicialNormalizado = v.KmInicial,
        KmFinalNormalizado = CASE 
            WHEN v.KmFinal >= v.KmInicial AND (v.KmFinal - v.KmInicial) <= @KM_MAXIMO_VIAGEM 
            THEN v.KmFinal ELSE NULL 
        END,
        FoiNormalizada = 0,
        TipoNormalizacao = NULL,
        DataNormalizacao = GETDATE()
    FROM Viagem v
    WHERE v.Status = 'Realizada'
      AND v.DataInicial >= @DataLimite
      AND (@ForcarReprocessamento = 1 OR v.DataNormalizacao IS NULL)
      AND v.DataInicial <= DATEADD(DAY, 7, @Hoje)
      AND (v.DataFinal IS NULL OR v.DataFinal >= v.DataInicial)
      AND (v.DataFinal IS NULL OR v.DataFinal <= DATEADD(DAY, 7, @Hoje))
      AND YEAR(v.DataInicial) >= 2020
      AND YEAR(v.DataInicial) <= @AnoAtual + 1
    
    DECLARE @NormaisCopiad INT = @@ROWCOUNT
    PRINT '         - Viagens normais: ' + CAST(@NormaisCopiad AS VARCHAR)
    
    -- =========================================================================
    -- PASSO 2: Corrigir anos futuros (ex: 2055 → 2025)
    -- =========================================================================
    UPDATE v
    SET 
        DataInicialNormalizada = CASE 
            WHEN YEAR(v.DataInicial) > @AnoAtual + 1 
            THEN DATEFROMPARTS(@AnoAtual, MONTH(v.DataInicial), 
                 CASE WHEN DAY(v.DataInicial) > 28 AND MONTH(v.DataInicial) = 2 THEN 28 ELSE DAY(v.DataInicial) END)
            ELSE v.DataInicial
        END,
        DataFinalNormalizada = CASE 
            WHEN v.DataFinal IS NOT NULL AND YEAR(v.DataFinal) > @AnoAtual + 1 
            THEN DATEFROMPARTS(@AnoAtual, MONTH(v.DataFinal), 
                 CASE WHEN DAY(v.DataFinal) > 28 AND MONTH(v.DataFinal) = 2 THEN 28 ELSE DAY(v.DataFinal) END)
            WHEN v.DataFinal IS NULL THEN DATEFROMPARTS(@AnoAtual, MONTH(v.DataInicial), 
                 CASE WHEN DAY(v.DataInicial) > 28 AND MONTH(v.DataInicial) = 2 THEN 28 ELSE DAY(v.DataInicial) END)
            ELSE v.DataFinal
        END,
        HoraInicioNormalizada = CAST(v.HoraInicio AS TIME),
        HoraFimNormalizada = CAST(v.HoraFim AS TIME),
        KmInicialNormalizado = v.KmInicial,
        KmFinalNormalizado = CASE 
            WHEN v.KmFinal >= v.KmInicial AND (v.KmFinal - v.KmInicial) <= @KM_MAXIMO_VIAGEM 
            THEN v.KmFinal ELSE NULL 
        END,
        FoiNormalizada = 1,
        TipoNormalizacao = 'ANO_CORRIGIDO_' + CAST(YEAR(v.DataInicial) AS VARCHAR) + '_PARA_' + CAST(@AnoAtual AS VARCHAR),
        DataNormalizacao = GETDATE()
    FROM Viagem v
    WHERE v.Status = 'Realizada'
      AND (@ForcarReprocessamento = 1 OR v.DataNormalizacao IS NULL)
      AND (YEAR(v.DataInicial) > @AnoAtual + 1 OR 
           (v.DataFinal IS NOT NULL AND YEAR(v.DataFinal) > @AnoAtual + 1))
    
    SET @TotalNormalizadas = @TotalNormalizadas + @@ROWCOUNT
    PRINT '         - Anos futuros corrigidos: ' + CAST(@@ROWCOUNT AS VARCHAR)
    
    -- =========================================================================
    -- PASSO 3: Corrigir DataFinal anterior a DataInicial
    -- =========================================================================
    UPDATE v
    SET 
        DataInicialNormalizada = v.DataInicial,
        DataFinalNormalizada = v.DataInicial,
        HoraInicioNormalizada = CAST(v.HoraInicio AS TIME),
        HoraFimNormalizada = CAST(v.HoraFim AS TIME),
        KmInicialNormalizado = v.KmInicial,
        KmFinalNormalizado = CASE 
            WHEN v.KmFinal >= v.KmInicial AND (v.KmFinal - v.KmInicial) <= @KM_MAXIMO_VIAGEM 
            THEN v.KmFinal ELSE NULL 
        END,
        FoiNormalizada = 1,
        TipoNormalizacao = 'DATA_FINAL_CORRIGIDA_PARA_MESMO_DIA',
        DataNormalizacao = GETDATE()
    FROM Viagem v
    WHERE v.Status = 'Realizada'
      AND v.DataInicial >= @DataLimite
      AND (@ForcarReprocessamento = 1 OR v.DataNormalizacao IS NULL)
      AND v.DataFinal IS NOT NULL
      AND v.DataFinal < v.DataInicial
    
    SET @TotalNormalizadas = @TotalNormalizadas + @@ROWCOUNT
    PRINT '         - DataFinal < DataInicial: ' + CAST(@@ROWCOUNT AS VARCHAR)
    
    -- =========================================================================
    -- PASSO 4: Corrigir durações excessivas baseado no padrão do veículo
    -- =========================================================================
    UPDATE v
    SET 
        DataInicialNormalizada = v.DataInicial,
        DataFinalNormalizada = CASE 
            WHEN p.TipoUso = 'DIARIO' THEN v.DataInicial
            ELSE DATEADD(MINUTE, p.MaxDuracaoNormalMinutos, v.DataInicial)
        END,
        HoraInicioNormalizada = CAST(v.HoraInicio AS TIME),
        HoraFimNormalizada = CAST(v.HoraFim AS TIME),
        MinutosNormalizado = CASE 
            WHEN p.TipoUso = 'DIARIO' THEN CAST(p.MediaDuracaoMinutos AS INT)
            ELSE p.MaxDuracaoNormalMinutos
        END,
        KmInicialNormalizado = v.KmInicial,
        KmFinalNormalizado = CASE 
            WHEN v.KmFinal >= v.KmInicial AND (v.KmFinal - v.KmInicial) <= @KM_MAXIMO_VIAGEM 
            THEN v.KmFinal ELSE NULL 
        END,
        FoiNormalizada = 1,
        TipoNormalizacao = 'DURACAO_AJUSTADA_' + p.TipoUso,
        DataNormalizacao = GETDATE()
    FROM Viagem v
    INNER JOIN VeiculoPadraoViagem p ON v.VeiculoId = p.VeiculoId
    WHERE v.Status = 'Realizada'
      AND v.DataInicial >= @DataLimite
      AND v.DataNormalizacao IS NULL
      AND v.Minutos IS NOT NULL
      AND v.Minutos > p.MaxDuracaoNormalMinutos * 2
    
    SET @TotalNormalizadas = @TotalNormalizadas + @@ROWCOUNT
    PRINT '         - Durações excessivas: ' + CAST(@@ROWCOUNT AS VARCHAR)
    
    -- =========================================================================
    -- PASSO 5: Corrigir KM invertido (KmFinal < KmInicial)
    -- =========================================================================
    UPDATE v
    SET 
        KmInicialNormalizado = v.KmFinal,
        KmFinalNormalizado = v.KmInicial,
        FoiNormalizada = 1,
        TipoNormalizacao = COALESCE(TipoNormalizacao + '; ', '') + 'KM_INVERTIDO',
        DataNormalizacao = GETDATE()
    FROM Viagem v
    WHERE v.Status = 'Realizada'
      AND v.DataInicial >= @DataLimite
      AND v.KmInicial IS NOT NULL 
      AND v.KmFinal IS NOT NULL
      AND v.KmFinal < v.KmInicial
      AND (v.KmInicial - v.KmFinal) <= @KM_MAXIMO_VIAGEM
    
    SET @TotalNormalizadas = @TotalNormalizadas + @@ROWCOUNT
    PRINT '         - KM invertido: ' + CAST(@@ROWCOUNT AS VARCHAR)
    
    -- =========================================================================
    -- PASSO 6: ESTIMAR KM OUTLIER BASEADO EM ABASTECIMENTO
    -- =========================================================================
    UPDATE v
    SET 
        KmInicialNormalizado = v.KmInicial,
        KmFinalNormalizado = v.KmInicial + CAST(
            p.MediaKmPorDia * 
            GREATEST(1, DATEDIFF(DAY, 
                COALESCE(v.DataInicialNormalizada, v.DataInicial), 
                COALESCE(v.DataFinalNormalizada, v.DataFinal, v.DataInicial)))
            AS DECIMAL(18,2)),
        FoiNormalizada = 1,
        TipoNormalizacao = COALESCE(v.TipoNormalizacao + '; ', '') + 'KM_ESTIMADO_ABASTECIMENTO',
        DataNormalizacao = GETDATE()
    FROM Viagem v
    INNER JOIN VeiculoPadraoViagem p ON v.VeiculoId = p.VeiculoId
    WHERE v.Status = 'Realizada'
      AND v.DataInicial >= @DataLimite
      AND v.KmInicial IS NOT NULL 
      AND v.KmFinal IS NOT NULL
      AND v.KmFinal > v.KmInicial
      AND (v.KmFinal - v.KmInicial) > @KM_MAXIMO_VIAGEM
      AND p.MediaKmPorDia IS NOT NULL
      AND p.MediaKmPorDia > 0
      AND v.KmFinalNormalizado IS NULL
    
    DECLARE @KmEstimados INT = @@ROWCOUNT
    SET @TotalNormalizadas = @TotalNormalizadas + @KmEstimados
    PRINT '         - KM estimados (abastecimento): ' + CAST(@KmEstimados AS VARCHAR)
    
    -- =========================================================================
    -- PASSO 7: KM outlier SEM dados de abastecimento → ANULAR
    -- =========================================================================
    UPDATE v
    SET 
        KmInicialNormalizado = NULL,
        KmFinalNormalizado = NULL,
        FoiNormalizada = 1,
        TipoNormalizacao = COALESCE(v.TipoNormalizacao + '; ', '') + 'KM_ANULADO_OUTLIER',
        DataNormalizacao = GETDATE()
    FROM Viagem v
    LEFT JOIN VeiculoPadraoViagem p ON v.VeiculoId = p.VeiculoId
    WHERE v.Status = 'Realizada'
      AND v.DataInicial >= @DataLimite
      AND v.KmInicial IS NOT NULL 
      AND v.KmFinal IS NOT NULL
      AND v.KmFinal > v.KmInicial
      AND (v.KmFinal - v.KmInicial) > @KM_MAXIMO_VIAGEM
      AND (p.MediaKmPorDia IS NULL OR p.MediaKmPorDia = 0)
      AND v.KmFinalNormalizado IS NULL
    
    DECLARE @KmAnulados INT = @@ROWCOUNT
    SET @TotalNormalizadas = @TotalNormalizadas + @KmAnulados
    PRINT '         - KM anulados (sem base): ' + CAST(@KmAnulados AS VARCHAR)
    
    -- =========================================================================
    -- PASSO 8: Recalcular MinutosNormalizado
    -- =========================================================================
    UPDATE v
    SET MinutosNormalizado = 
        CASE 
            WHEN v.DataInicialNormalizada IS NOT NULL 
                 AND v.DataFinalNormalizada IS NOT NULL
                 AND v.HoraInicioNormalizada IS NOT NULL
                 AND v.HoraFimNormalizada IS NOT NULL
            THEN DATEDIFF(MINUTE, 
                 DATEADD(SECOND, 
                     DATEPART(HOUR, v.HoraInicioNormalizada) * 3600 + DATEPART(MINUTE, v.HoraInicioNormalizada) * 60,
                     CAST(CAST(v.DataInicialNormalizada AS DATE) AS DATETIME)),
                 DATEADD(SECOND, 
                     DATEPART(HOUR, v.HoraFimNormalizada) * 3600 + DATEPART(MINUTE, v.HoraFimNormalizada) * 60,
                     CAST(CAST(v.DataFinalNormalizada AS DATE) AS DATETIME)))
            ELSE v.MinutosNormalizado
        END
    FROM Viagem v
    WHERE v.DataNormalizacao IS NOT NULL
      AND v.DataInicialNormalizada IS NOT NULL
      AND v.MinutosNormalizado IS NULL
    
    PRINT '         - Minutos recalculados: ' + CAST(@@ROWCOUNT AS VARCHAR)
    
    -- =========================================================================
    -- PASSO 9: Garantir MinutosNormalizado válido
    -- =========================================================================
    UPDATE Viagem
    SET MinutosNormalizado = CASE 
            WHEN MinutosNormalizado < 0 THEN ABS(MinutosNormalizado)
            WHEN MinutosNormalizado > 43200 THEN NULL
            ELSE MinutosNormalizado
        END
    WHERE MinutosNormalizado IS NOT NULL
      AND (MinutosNormalizado < 0 OR MinutosNormalizado > 43200)
    
    PRINT '         Total corrigidas: ' + CAST(@TotalNormalizadas AS VARCHAR)
    
    RETURN @TotalNormalizadas
END
GO

PRINT '  [CREATE] Procedure sp_NormalizarViagens criada'
PRINT ''
GO

-- ============================================================================
-- PARTE 5: STORED PROCEDURE - INTEGRADA
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  PARTE 5: SP sp_AtualizarEstatisticasIntegrado'
PRINT '────────────────────────────────────────────────────────────────────────'

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'sp_AtualizarEstatisticasIntegrado')
BEGIN
    DROP PROCEDURE sp_AtualizarEstatisticasIntegrado
    PRINT '  [DROP] Procedure sp_AtualizarEstatisticasIntegrado removida'
END
GO

CREATE PROCEDURE sp_AtualizarEstatisticasIntegrado
    @DiasParaProcessar INT = 30,
    @ApenasHoje BIT = 0
AS
BEGIN
    SET NOCOUNT ON
    
    DECLARE @Inicio DATETIME = GETDATE()
    
    PRINT ''
    PRINT '══════════════════════════════════════════════════════════════════════'
    PRINT '  FROTIX - Atualização Integrada de Estatísticas'
    PRINT '  Início: ' + CONVERT(VARCHAR(20), @Inicio, 120)
    PRINT '══════════════════════════════════════════════════════════════════════'
    
    -- =========================================================================
    -- ETAPA 1: Atualizar padrões de veículos (1x por dia às 01:00)
    -- =========================================================================
    IF DATEPART(HOUR, GETDATE()) = 1
    BEGIN
        PRINT ''
        PRINT '  >> ETAPA 1/3: Atualizando padrões de veículos...'
        EXEC sp_AtualizarPadroesVeiculos
    END
    ELSE
    BEGIN
        PRINT ''
        PRINT '  >> ETAPA 1/3: Padrões de veículos (pulado - só executa às 01:00)'
    END
    
    -- =========================================================================
    -- ETAPA 2: Normalizar viagens
    -- =========================================================================
    PRINT ''
    PRINT '  >> ETAPA 2/3: Normalizando viagens...'
    EXEC sp_NormalizarViagens @DiasParaProcessar = @DiasParaProcessar
    
    -- =========================================================================
    -- ETAPA 3: Atualizar estatísticas
    -- =========================================================================
    PRINT ''
    PRINT '  >> ETAPA 3/3: Atualizando estatísticas...'
    
    IF @ApenasHoje = 1
        EXEC sp_AtualizarViagemEstatistica @ApenasHoje = 1
    ELSE
        EXEC sp_AtualizarViagemEstatistica @DataInicio = NULL, @DataFim = NULL
    
    -- =========================================================================
    -- RESUMO
    -- =========================================================================
    DECLARE @Fim DATETIME = GETDATE()
    DECLARE @Duracao INT = DATEDIFF(SECOND, @Inicio, @Fim)
    
    PRINT ''
    PRINT '══════════════════════════════════════════════════════════════════════'
    PRINT '  Atualização integrada concluída!'
    PRINT '  Duração: ' + CAST(@Duracao AS VARCHAR) + ' segundos'
    PRINT '  Fim: ' + CONVERT(VARCHAR(20), @Fim, 120)
    PRINT '══════════════════════════════════════════════════════════════════════'
END
GO

PRINT '  [CREATE] Procedure sp_AtualizarEstatisticasIntegrado criada'
PRINT ''
GO

-- ============================================================================
-- RESUMO FINAL
-- ============================================================================

PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  SCRIPT 02 CONCLUÍDO COM SUCESSO!                                    ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''
PRINT '  Campos adicionados na tabela Viagem:'
PRINT '    ✓ DataInicialNormalizada, DataFinalNormalizada'
PRINT '    ✓ HoraInicioNormalizada, HoraFimNormalizada'
PRINT '    ✓ MinutosNormalizado'
PRINT '    ✓ KmInicialNormalizado, KmFinalNormalizado'
PRINT '    ✓ FoiNormalizada, TipoNormalizacao, DataNormalizacao'
PRINT ''
PRINT '  Tabela criada:'
PRINT '    ✓ VeiculoPadraoViagem (padrões de uso por veículo)'
PRINT ''
PRINT '  Stored Procedures criadas:'
PRINT '    ✓ sp_AtualizarPadroesVeiculos'
PRINT '    ✓ sp_NormalizarViagens'
PRINT '    ✓ sp_AtualizarEstatisticasIntegrado'
PRINT ''
PRINT '  Próximo passo: Execute o script 03_SP_AtualizarViagemEstatistica.sql'
PRINT ''
PRINT 'Fim: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT ''
GO
