-- ============================================================================
-- FROTIX - 01: CRIAR TABELA VIAGEM ESTATISTICA
-- ============================================================================
-- Este script cria a tabela que armazena as estatísticas pré-calculadas
-- para o Dashboard de Viagens
--
-- EXECUÇÃO: Primeiro script a ser executado
-- ============================================================================

USE FrotiX
GO

PRINT ''
PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  FROTIX - SCRIPT 01: TABELA VIAGEM ESTATISTICA                       ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''
PRINT 'Início: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT ''

-- ============================================================================
-- DROP TABELA E ÍNDICES (se existirem)
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 1: Removendo estruturas existentes'
PRINT '────────────────────────────────────────────────────────────────────────'

-- Remover índices primeiro
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ViagemEstatistica_DataRef_Viagens' AND object_id = OBJECT_ID('ViagemEstatistica'))
BEGIN
    DROP INDEX IX_ViagemEstatistica_DataRef_Viagens ON ViagemEstatistica
    PRINT '  [DROP] Índice IX_ViagemEstatistica_DataRef_Viagens removido'
END

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ViagemEstatistica_DataRef_Custos' AND object_id = OBJECT_ID('ViagemEstatistica'))
BEGIN
    DROP INDEX IX_ViagemEstatistica_DataRef_Custos ON ViagemEstatistica
    PRINT '  [DROP] Índice IX_ViagemEstatistica_DataRef_Custos removido'
END

IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ViagemEstatistica_DataReferencia' AND object_id = OBJECT_ID('ViagemEstatistica'))
BEGIN
    DROP INDEX IX_ViagemEstatistica_DataReferencia ON ViagemEstatistica
    PRINT '  [DROP] Índice IX_ViagemEstatistica_DataReferencia removido'
END

-- Remover tabela
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'ViagemEstatistica')
BEGIN
    DECLARE @RegistrosRemovidos INT
    SELECT @RegistrosRemovidos = COUNT(*) FROM ViagemEstatistica
    DROP TABLE ViagemEstatistica
    PRINT '  [DROP] Tabela ViagemEstatistica removida (' + CAST(@RegistrosRemovidos AS VARCHAR) + ' registros)'
END
ELSE
BEGIN
    PRINT '  [INFO] Tabela ViagemEstatistica não existia'
END

PRINT ''

-- ============================================================================
-- CRIAR TABELA VIAGEM ESTATISTICA
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 2: Criando tabela ViagemEstatistica'
PRINT '────────────────────────────────────────────────────────────────────────'

CREATE TABLE ViagemEstatistica (
    ViagemEstatisticaId INT IDENTITY(1,1) PRIMARY KEY,
    DataReferencia DATE NOT NULL,
    
    -- Contadores de viagens
    TotalViagens INT DEFAULT 0,
    ViagensFinalizadas INT DEFAULT 0,
    ViagensEmAndamento INT DEFAULT 0,
    ViagensAgendadas INT DEFAULT 0,
    ViagensCanceladas INT DEFAULT 0,
    
    -- Custos
    CustoTotal DECIMAL(18,2) DEFAULT 0,
    CustoVeiculo DECIMAL(18,2) DEFAULT 0,
    CustoMotorista DECIMAL(18,2) DEFAULT 0,
    CustoOperador DECIMAL(18,2) DEFAULT 0,
    CustoLavador DECIMAL(18,2) DEFAULT 0,
    CustoCombustivel DECIMAL(18,2) DEFAULT 0,
    
    -- Quilometragem
    QuilometragemTotal DECIMAL(18,2) DEFAULT 0,
    QuilometragemMedia DECIMAL(18,2) DEFAULT 0,
    
    -- JSONs com agregações detalhadas
    ViagensPorStatusJson NVARCHAR(MAX) NULL,
    ViagensPorMotoristaJson NVARCHAR(MAX) NULL,
    ViagensPorVeiculoJson NVARCHAR(MAX) NULL,
    ViagensPorFinalidadeJson NVARCHAR(MAX) NULL,
    ViagensPorRequisitanteJson NVARCHAR(MAX) NULL,
    ViagensPorSetorJson NVARCHAR(MAX) NULL,
    CustosPorMotoristaJson NVARCHAR(MAX) NULL,
    CustosPorVeiculoJson NVARCHAR(MAX) NULL,
    KmPorVeiculoJson NVARCHAR(MAX) NULL,
    CustosPorTipoJson NVARCHAR(MAX) NULL,
    
    -- Auditoria
    DataCriacao DATETIME2 DEFAULT GETDATE(),
    DataAtualizacao DATETIME2 DEFAULT GETDATE()
)

PRINT '  [CREATE] Tabela ViagemEstatistica criada'
PRINT '           - 5 colunas de contagem (TotalViagens, Finalizadas, EmAndamento, Agendadas, Canceladas)'
PRINT '           - 6 colunas de custo (Total, Veiculo, Motorista, Operador, Lavador, Combustivel)'
PRINT '           - 2 colunas de KM (Total, Media)'
PRINT '           - 10 colunas JSON para agregações'
PRINT '           - 2 colunas de auditoria'
PRINT ''

-- ============================================================================
-- CRIAR ÍNDICES
-- ============================================================================

PRINT '────────────────────────────────────────────────────────────────────────'
PRINT '  ETAPA 3: Criando índices'
PRINT '────────────────────────────────────────────────────────────────────────'

-- Índice único por data
CREATE UNIQUE NONCLUSTERED INDEX IX_ViagemEstatistica_DataReferencia 
    ON ViagemEstatistica(DataReferencia)
PRINT '  [CREATE] IX_ViagemEstatistica_DataReferencia (UNIQUE)'

-- Índice para consultas de custos
CREATE NONCLUSTERED INDEX IX_ViagemEstatistica_DataRef_Custos 
    ON ViagemEstatistica(DataReferencia)
    INCLUDE (CustoTotal, CustoVeiculo, CustoMotorista, CustoLavador, CustoCombustivel, QuilometragemTotal)
PRINT '  [CREATE] IX_ViagemEstatistica_DataRef_Custos'

-- Índice para consultas de contagem
CREATE NONCLUSTERED INDEX IX_ViagemEstatistica_DataRef_Viagens 
    ON ViagemEstatistica(DataReferencia)
    INCLUDE (TotalViagens, ViagensFinalizadas, ViagensAgendadas, ViagensCanceladas, ViagensEmAndamento)
PRINT '  [CREATE] IX_ViagemEstatistica_DataRef_Viagens'

PRINT ''

-- ============================================================================
-- RESUMO FINAL
-- ============================================================================

PRINT '╔══════════════════════════════════════════════════════════════════════╗'
PRINT '║  SCRIPT 01 CONCLUÍDO COM SUCESSO!                                    ║'
PRINT '╚══════════════════════════════════════════════════════════════════════╝'
PRINT ''
PRINT '  Objetos criados:'
PRINT '    ✓ Tabela: ViagemEstatistica'
PRINT '    ✓ Índice: IX_ViagemEstatistica_DataReferencia (UNIQUE)'
PRINT '    ✓ Índice: IX_ViagemEstatistica_DataRef_Custos'
PRINT '    ✓ Índice: IX_ViagemEstatistica_DataRef_Viagens'
PRINT ''
PRINT '  Próximo passo: Execute o script 02_NormalizacaoIntegrada.sql'
PRINT ''
PRINT 'Fim: ' + CONVERT(VARCHAR(20), GETDATE(), 120)
PRINT ''
GO
